public interface Bidimensional {

  float getX();

  void setX(float x) throws MedidaInvalidaException;

  float getY();

  void setY(float y) throws MedidaInvalidaException;

  double obterArea();
}
