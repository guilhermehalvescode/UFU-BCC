public class MedidaInvalidaException extends Exception {
  public MedidaInvalidaException(String message) {
    super(message);
  }
}
